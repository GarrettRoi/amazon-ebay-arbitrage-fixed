const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');

// Load env vars
dotenv.config();

// Create Sequelize instance
let sequelizeConfig;

if (process.env.NODE_ENV === 'production') {
  // Production configuration using DATABASE_URL
  sequelizeConfig = {
    dialect: 'postgres',
    dialectOptions: {
      ssl: {
        require: true,
        rejectUnauthorized: false
      }
    },
    logging: false
  };
} else {
  // Development configuration using local database
  sequelizeConfig = {
    host: 'localhost',
    port: 5432,
    database: 'amazon_ebay_arbitrage',
    username: 'postgres',
    password: 'postgres',
    dialect: 'postgres',
    logging: console.log
  };
}

const sequelize = process.env.NODE_ENV === 'production' 
  ? new Sequelize(process.env.DATABASE_URL, sequelizeConfig)
  : new Sequelize(sequelizeConfig);

// Test the connection
const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('PostgreSQL Connected');
    return sequelize;
  } catch (error) {
    console.error(`Error connecting to PostgreSQL: ${error.message}`);
    process.exit(1);
  }
};

module.exports = { sequelize, connectDB };
